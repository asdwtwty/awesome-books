# HEM 模块专家审校稿

说明：本文件由 `cards/HEM/*.json` 自动映射生成，阅读结构遵循字段规范中的专家审校格式建议。

## HEM-001 火力威胁阶段四肢致命出血的立即止血带处置

**核心问题**

火力威胁阶段何时立即使用四肢止血带

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：basic
- 适用阶段：Care Under Threat
- 适用场景：战场火力威胁现场，伤员尚未完全转入掩体
- 适用对象：成人战伤伤员
- 前置条件：仍处于 Care Under Fire/Threat；存在疑似或明确致命性四肢外出血
- 不覆盖范围：不覆盖止血带复位与转换；不覆盖交界区出血；不覆盖气道处置

**触发条件**

- 对战术态势允许实施止血
- 出血部位解剖上适合止血带使用

**识别线索**

- 四肢喷射样或持续大量出血
- 衣物快速被血浸透
- 创伤性截肢

**标准动作**

- 1. 对解剖上适合止血带控制的致命性四肢外出血立即使用 CoTCCC 推荐四肢止血带；优先级：immediate；条件：战术上可行；时间要求：立即；说明：可先指导伤员自救

**分支决策**

- 触发条件：出血解剖上适合止血带控制且具有生命威胁；下一步：立即应用四肢止血带；依据：该阶段唯一优先处置是快速压制致命性外出血并保持战术行动能力；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 等待进入全面评估后再上止血带
- 对明显致命出血只做口头观察不处置

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Care Under Fire/Threat | 6.b
  - 原文：Use a CoTCCC-recommended limb tourniquet for hemorrhage that is anatomically amenable to tourniquet use.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：依据 2026 TCCC 火力威胁阶段止血要求抽取

**评测要点**

- 是否提到火力威胁阶段即可处理致命性外出血
- 是否提到适用于解剖上可用止血带控制的四肢出血
- 是否提到应立即使用 CoTCCC 推荐四肢止血带

---

## HEM-002 火力威胁阶段隔衣高位紧扎止血带的适用逻辑

**核心问题**

火力威胁阶段止血带为何允许隔衣高位紧扎

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：basic
- 适用阶段：Care Under Threat
- 适用场景：战场火力威胁现场
- 适用对象：成人战伤伤员
- 前置条件：存在疑似致命性四肢出血；出血点不易立即暴露或明确
- 不覆盖范围：不覆盖 Tactical Field Care 阶段对皮肤重新定位；不覆盖止血带转换

**触发条件**

- 生命威胁性出血部位不清
- 战术态势不允许耗时暴露伤口

**识别线索**

- 血液来源位置被衣物遮挡
- 现场仍存在火力威胁
- 伤员需尽快转移到掩体

**标准动作**

- 1. 将止血带隔着制服放在伤肢尽量近端位置并拧紧；优先级：immediate；条件：生命威胁出血部位不清晰；时间要求：立即；说明：目标是缩短处置时间并先控制致命出血
- 2. 尽快将伤员转移到掩体后再做暴露与复评；优先级：high；条件：完成初始止血后；时间要求：尽快；说明：后续在 Tactical Field Care 阶段重新定位

**分支决策**

- 触发条件：生命威胁性出血部位不能迅速明确；下一步：高位紧扎放在伤肢最靠近躯干的位置并转移伤员；依据：该做法优先满足战术环境下的速度和止血需求；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 在火力下脱衣暴露寻找精确出血点
- 把止血带放在过远端位置导致止血不足

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Care Under Fire/Threat | 6.c
  - 原文：Apply the limb tourniquet over the uniform clearly proximal to the bleeding site(s). If the site of the life-threatening bleeding is not readily apparent, place the tourniquet high and tight on the injured limb and move the casualty to cover.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：强调火力威胁阶段的速度优先策略

**评测要点**

- 是否提到出血点不明时允许高位紧扎
- 是否提到可隔衣放置
- 是否提到该策略服务于快速止血和转移到掩体

---

## HEM-003 Tactical Field Care 阶段未识别出血源的复查与控制

**核心问题**

Tactical Field Care 阶段如何重新评估未识别出血源

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：reassessment
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台复评
- 适用对象：成人战伤伤员
- 前置条件：已进入 Tactical Field Care 或 TACEVAC；需要系统评估大出血
- 不覆盖范围：不覆盖气道和呼吸系统评估；不覆盖液体复苏细节

**触发条件**

- 存在可能遗漏出血
- 伤员已从火力威胁阶段转入相对安全环境

**识别线索**

- 衣物或担架下有隐匿血迹
- 生命体征提示休克
- 既往止血措施效果不确定

**标准动作**

- 1. 系统评估未识别出血并控制所有出血来源；优先级：immediate；条件：开始 Massive Hemorrhage 模块评估；时间要求：立即；说明：包括重新暴露伤口和检查已置入止血措施

**分支决策**

- 无

**复评要点**

- 是否仍有未识别活动性出血
- 所有出血源是否均已获得控制
- 先前止血措施是否仍有效

**常见错误**

- 只关注已知伤口而漏查其他部位
- 未复评既往止血带和敷料效果

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.a
  - 原文：Assess for unrecognized hemorrhage and control all sources of bleeding.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：适用于 TFC 与 TACEVAC 的大出血复查起点

**评测要点**

- 是否提到评估未识别出血
- 是否提到控制所有出血来源
- 是否体现 Tactical Field Care 的系统复查特点

---

## HEM-004 需直接对皮肤放置止血带的四肢出血场景

**核心问题**

何种四肢出血应直接对皮肤放置止血带

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：procedure
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台复评
- 适用对象：成人战伤伤员
- 前置条件：已暴露伤口并进入系统止血评估
- 不覆盖范围：不覆盖交界区止血；不覆盖头颈部 iTClamp

**触发条件**

- 存在致命性外出血
- 出血部位解剖上适合止血带控制
- 存在任何创伤性截肢

**识别线索**

- 四肢活动性大出血
- 创伤性截肢或近截肢
- 出血位于止血带可有效压闭的肢体段

**标准动作**

- 1. 将 CoTCCC 推荐四肢止血带直接放在皮肤上并置于出血点近端 2 至 3 英寸处；优先级：immediate；条件：致命性四肢外出血或创伤性截肢；时间要求：立即；说明：直接皮肤放置优先于隔衣放置

**分支决策**

- 无

**复评要点**

- 无

**常见错误**

- 仍沿用火力威胁阶段的隔衣位置而不重新贴皮
- 止血带离出血点过远或过近

**记录要求**

- 记录止血带放置时间

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.a
  - 原文：If not already done, use a CoTCCC-recommended limb tourniquet to control life-threatening external hemorrhage that is anatomically amenable to tourniquet use or for any traumatic amputation. Apply directly to the skin 2-3 inches above the bleeding site.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：对应 Tactical Field Care 止血带标准放置

**评测要点**

- 是否提到适用于致命性四肢外出血和创伤性截肢
- 是否提到直接对皮肤放置
- 是否提到距离出血点近端 2 至 3 英寸

---

## HEM-005 首根止血带后仍出血时的升级处置

**核心问题**

首根止血带后仍出血时下一步是什么

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台复评
- 适用对象：成人战伤伤员
- 前置条件：已完成首根止血带放置；四肢出血可用止血带控制
- 不覆盖范围：不覆盖止血带转换；不覆盖后送交接

**触发条件**

- 首根止血带后仍有活动性出血
- 首根止血带后远端脉搏仍可触及

**识别线索**

- 敷料持续浸透
- 出血未停止
- 远端脉搏未消失

**标准动作**

- 1. 在首根止血带旁并列追加第二根止血带；优先级：immediate；条件：首根止血带未完全控制出血；时间要求：立即；说明：目标是同时终止出血并消除远端脉搏

**分支决策**

- 触发条件：首根止血带后仍持续出血或远端脉搏持续存在；下一步：追加第二根止血带并列放置；依据：单根压力不足以完全阻断出血和远端血流；分支类型：escalation

**复评要点**

- 活动性出血是否停止
- 远端脉搏是否消失

**常见错误**

- 只继续拧紧首根止血带而未及时追加第二根
- 止血后未检查远端脉搏

**记录要求**

- 记录追加止血带时间
- 记录止血效果

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.a
  - 原文：If bleeding is not controlled with the first tourniquet, apply a second tourniquet side-by-side with the first.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：按字段规范示例补齐

**评测要点**

- 是否提到并列追加第二根止血带
- 是否提到继续评估出血是否停止
- 是否提到远端脉搏应消失

---

## HEM-006 优先使用止血纱布而非四肢止血带的压迫性出血场景

**核心问题**

何种情况优先选择止血纱布而非四肢止血带

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：出血属于可压迫性外出血
- 不覆盖范围：不覆盖明确适合四肢止血带的肢体出血；不覆盖头颈部 iTClamp 特殊场景

**触发条件**

- 出血不适合四肢止血带使用
- 作为止血带移除或转换后的辅助止血

**识别线索**

- 出血部位位于交界区或其他止血带难以有效压闭区域
- 需要以填塞和直接压迫实现止血

**标准动作**

- 1. 使用 CoTCCC 推荐止血敷料进行填塞并直接压迫；优先级：immediate；条件：可压迫性外出血不适合四肢止血带使用或作为止血带移除辅助手段；时间要求：立即；说明：首选 Combat Gauze

**分支决策**

- 触发条件：出血不能通过四肢止血带有效控制；下一步：改用止血敷料填塞加直接压迫；依据：该类伤口更依赖局部填塞压迫实现止血；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 对交界区出血继续尝试无效四肢止血带
- 移除止血带时未准备止血敷料承接

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.b
  - 原文：For compressible (external) hemorrhage not amenable to limb tourniquet use or as an adjunct to tourniquet removal, use Combat Gauze as the CoTCCC hemostatic dressing of choice.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：明确止血敷料与四肢止血带的适应边界

**评测要点**

- 是否提到可压迫性外出血不适合止血带使用
- 是否提到止血带移除时可作为辅助手段
- 是否提到应使用止血敷料并直接压迫

---

## HEM-007 Combat Gauze 的首选适用场景

**核心问题**

Combat Gauze 的适用场景是什么

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：recognition
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：需要局部止血敷料控制出血
- 不覆盖范围：不覆盖具体替代品边界；不覆盖 XStat 现场移除要求

**触发条件**

- 可压迫性外出血不适合四肢止血带使用
- 止血带转换或移除时需要承接止血

**识别线索**

- 伤口可进行填塞与压迫
- 需要 CoTCCC 首选止血材料

**标准动作**

- 1. 优先选用 Combat Gauze 作为止血敷料；优先级：high；条件：适应证满足且物资可用；时间要求：尽快；说明：属于 CoTCCC hemostatic dressing of choice

**分支决策**

- 无

**复评要点**

- 无

**常见错误**

- 无

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.b
  - 原文：use Combat Gauze as the CoTCCC hemostatic dressing of choice.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：突出首选材料定位

**评测要点**

- 是否提到 Combat Gauze 是首选止血敷料
- 是否提到适用于不适合四肢止血带的可压迫性外出血
- 是否提到也可作为止血带移除辅助手段

---

## HEM-008 Celox Gauze、ChitoGauze、XStat 与 iTClamp 的替代使用边界

**核心问题**

Celox Gauze、ChitoGauze、XStat、iTClamp 的替代使用边界是什么

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：advanced
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：已判断需要止血辅具
- 不覆盖范围：不覆盖头颈部 iTClamp 特殊监测要求；不覆盖 XStat 现场不得移除规则细节

**触发条件**

- 无

**识别线索**

- Combat Gauze 不可得或需更匹配的替代品
- 伤口为深而窄的交界区伤道
- 伤口边缘可重新对合

**标准动作**

- 1. 可选用 Celox Gauze 或 ChitoGauze 作为替代止血纱布；优先级：high；条件：需要止血敷料且 Combat Gauze 不可得或需替代；时间要求：尽快；说明：与首选止血敷料同属替代选项
- 2. 对于深而窄的交界区伤道优先考虑 XStat；优先级：high；条件：deep narrow-tract junctional wound；时间要求：尽快；说明：XStat 最适配该类解剖形态
- 3. iTClamp 可单独使用，也可与止血敷料或 XStat 联合使用；优先级：high；条件：伤口边缘可重新对合或需要夹闭辅助止血；时间要求：尽快；说明：头颈部另见专项卡

**分支决策**

- 触发条件：深而窄的交界区伤道；下一步：优先考虑 XStat；依据：指南明确指出 XStat 最适用于此类伤道；分支类型：if_then
- 触发条件：需夹闭伤口边缘或联合局部止血材料；下一步：使用 iTClamp 单独或联合止血敷料或 XStat；依据：iTClamp 兼容独立或联合控制出血；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 把 XStat 泛化用于所有伤口类型
- 忽视 iTClamp 可与其他止血材料联合使用

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.b.1
  - 原文：Celox Gauze or ChitoGauze or XStat (best for deep, narrow-tract junctional wounds) iTClamp (may be used alone or in conjunction with hemostatic dressing or XStat)

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：整合替代止血辅具的边界

**评测要点**

- 是否提到 Celox Gauze 和 ChitoGauze 属替代止血纱布
- 是否提到 XStat 最适合深而窄的交界区伤道
- 是否提到 iTClamp 可单独或联合使用

---

## HEM-009 止血敷料直接压迫的标准持续时间

**核心问题**

止血敷料需要维持多长时间直接压迫

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：procedure
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：已放置止血敷料
- 不覆盖范围：不覆盖止血带压迫时间；不覆盖 iTClamp 压迫要求

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 1. 对止血敷料维持至少 3 分钟直接压迫；优先级：immediate；条件：使用常规止血敷料时；时间要求：至少 3 分钟；说明：XStat 可不要求直接压迫

**分支决策**

- 触发条件：使用 XStat；下一步：可省略至少 3 分钟直接压迫要求；依据：指南明确将 XStat 作为例外；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 压迫时间不足即过早松手检查
- 将 XStat 与常规止血敷料压迫要求混同

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.b.1
  - 原文：Hemostatic dressings should be applied with at least 3 minutes of direct pressure (optional for XStat).

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：压迫时间卡

**评测要点**

- 是否提到至少 3 分钟直接压迫
- 是否提到 XStat 为例外
- 是否表达为止血敷料通用要求

---

## HEM-010 XStat 现场使用后的保留原则

**核心问题**

XStat 的现场使用后为何不能移除

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：error_prevention
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：已在伤口中放置 XStat
- 不覆盖范围：不覆盖医院阶段清除处理

**触发条件**

- XStat 初始使用后仍需追加止血
- 现场人员考虑更换止血材料

**识别线索**

- 已有 XStat 在位
- 仍有渗血或需加强覆盖

**标准动作**

- 1. 保持已置入的 XStat 原位；优先级：immediate；条件：现场阶段；时间要求：持续；说明：不得在现场取出
- 2. 如止血不足，可在其上追加 XStat、其他止血辅具或创伤敷料；优先级：high；条件：初始 XStat 后仍需进一步控制出血；时间要求：尽快；说明：追加而非移除重来

**分支决策**

- 触发条件：XStat 控制不足；下一步：在其上追加止血辅具或创伤敷料；依据：指南要求现场保留 XStat，升级方式是覆盖追加；分支类型：escalation

**复评要点**

- 无

**常见错误**

- 在现场移除 XStat 重新填塞
- 误将 XStat 当作可像普通纱布一样取出更换

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.b.1
  - 原文：XStat is not to be removed in the field, but additional XStat, other hemostatic adjuncts, or trauma dressings may be applied over it.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：XStat 现场禁移除规则

**评测要点**

- 是否提到 XStat 现场不得移除
- 是否提到可在其上追加 XStat 或其他止血辅具
- 是否体现错误预防重点

---

## HEM-011 应尽快使用交界区止血带的出血场景

**核心问题**

何种出血应尽快使用交界区止血带

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：出血位点解剖上适合交界区止血带
- 不覆盖范围：不覆盖四肢常规止血带；不覆盖骨盆固定带

**触发条件**

- 出血位点适合使用交界区止血带

**识别线索**

- 伤口位于肢体近端或交界区，常规四肢止血带难以控制
- 现场具备交界区止血带

**标准动作**

- 1. 立即使用交界区止血带；优先级：immediate；条件：出血部位适合交界区止血带；时间要求：器材就绪后立即；说明：避免在器材已可用时延迟

**分支决策**

- 触发条件：出血位点适合交界区止血带使用；下一步：立刻上交界区止血带；依据：指南强调 once ready for use 不应延迟；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 交界区止血带可用后仍长时间仅靠手压
- 误把普通肢体止血带应用于无效的交界区位置

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.b.1
  - 原文：If the bleeding site is amenable to use of a junctional tourniquet, immediately apply a junctional tourniquet. Do not delay in the application of the junctional tourniquet once it is ready for use.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：交界区止血带适应证边界

**评测要点**

- 是否提到适用于可用交界区止血带的出血
- 是否提到应立即使用
- 是否提到器材就绪后不应拖延

---

## HEM-012 交界区止血带未到位前的过渡止血方法

**核心问题**

交界区止血带未到位前如何过渡止血

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：procedure
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：交界区止血带尚未到位或正在准备
- 不覆盖范围：不覆盖交界区止血带正式上带步骤

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 1. 在交界区止血带不可得或尚在准备时，使用止血敷料填塞并直接压迫；优先级：immediate；条件：无法立即完成交界区止血带应用；时间要求：立即；说明：作为过渡止血措施

**分支决策**

- 触发条件：交界区止血带未可用；下一步：先以止血敷料和直接压迫控制出血；依据：避免等待器材导致持续失血；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 等待交界区止血带时无过渡止血措施
- 只松散覆盖敷料而未施加直接压迫

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.b.1
  - 原文：Apply hemostatic dressings with direct pressure if a junctional tourniquet is not available or while the junctional tourniquet is being readied for use.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：交界区止血带准备期过渡止血

**评测要点**

- 是否提到交界区止血带未可用或在准备时的场景
- 是否提到止血敷料
- 是否提到直接压迫为过渡措施

---

## HEM-013 头颈部可重新对合伤口使用 iTClamp 的首选场景

**核心问题**

头颈部可重新对合伤口何时优先使用 iTClamp

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：头颈部外出血；伤口边缘可轻易重新对合
- 不覆盖范围：不覆盖眼眶周围禁用边界；不覆盖颈部气道监测细节

**触发条件**

- 头颈部伤口边缘可重新对合

**识别线索**

- 头颈部开放伤有活动性出血
- 创缘可以贴合夹闭
- 伤口可能适合先行填塞

**标准动作**

- 1. 若合适，先以止血敷料或 XStat 填塞伤口；优先级：high；条件：伤口腔隙需要填塞；时间要求：尽快；说明：先填塞后夹闭
- 2. 将 iTClamp 作为头颈部此类伤口的首选止血方式进行夹闭；优先级：immediate；条件：伤口边缘易于重新对合；时间要求：立即；说明：primary option

**分支决策**

- 无

**复评要点**

- 无

**常见错误**

- 无

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.c
  - 原文：For external hemorrhage of the head and neck where the wound edges can be easily re-approximated, the iTClamp may be used as a primary option for hemorrhage control. Wounds should be packed with a hemostatic dressing or XStat, if appropriate, prior to iTClamp application.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：头颈部 iTClamp 首选场景

**评测要点**

- 是否提到头颈部外出血
- 是否提到伤口边缘易于重新对合
- 是否提到 iTClamp 可作为首选并可先填塞止血材料

---

## HEM-014 颈部使用 iTClamp 后的重点气道监测

**核心问题**

颈部使用 iTClamp 后需要重点监测什么

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：reassessment
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：iTClamp 已用于颈部出血控制
- 不覆盖范围：不覆盖外科气道具体技术

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 1. 频繁进行气道监测；优先级：immediate；条件：颈部已置入 iTClamp；时间要求：持续；说明：重点关注进行性气道受压
- 2. 评估是否存在危及气道的扩张性血肿；优先级：high；条件：颈部肿胀或呼吸改变；时间要求：持续；说明：一旦有证据应考虑确定性气道

**分支决策**

- 触发条件：有扩张性血肿证据并可能危及气道；下一步：考虑建立确定性气道；依据：指南明确提示 expanding hematoma may compromise the airway；分支类型：escalation

**复评要点**

- 是否出现气道受威胁
- 是否形成或加重扩张性血肿
- 是否需要建立确定性气道

**常见错误**

- 颈部夹闭后忽视气道持续观察
- 出现扩张性血肿征象仍未提前准备确定性气道

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.c.2
  - 原文：If the iTClamp is applied to the neck, perform frequent airway monitoring and evaluate for an expanding hematoma that may compromise the airway. Consider placing a definitive airway if there is evidence of an expanding hematoma.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：颈部 iTClamp 复评重点

**评测要点**

- 是否提到频繁气道监测
- 是否提到评估扩张性血肿
- 是否提到必要时考虑确定性气道

---

## HEM-015 iTClamp 在眼眶周围的禁用边界

**核心问题**

iTClamp 的眼眶周围禁用边界是什么

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：error_prevention
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：考虑使用 iTClamp 控制头面部出血
- 不覆盖范围：不覆盖穿通性眼伤其他处置

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 无

**分支决策**

- 无

**复评要点**

- 无

**常见错误**

- 将 iTClamp 直接用于眼睑伤口
- 忽视距眶缘 1 cm 的禁用边界

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.c.3
  - 原文：DO NOT APPLY on or near the eye or eyelid (within 1cm of the orbit).

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：iTClamp 禁用边界

**评测要点**

- 是否提到 eye or eyelid
- 是否提到 within 1 cm of the orbit
- 是否表达为明确禁用

---

## HEM-016 失血性休克的初始现场识别标准

**核心问题**

失血性休克的初始现场识别标准是什么

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：recognition
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：正在进行大出血或循环初筛
- 不覆盖范围：不覆盖详细液体复苏顺序；不覆盖 TBI 目标血压

**触发条件**

- 大出血评估完成后进行休克初筛

**识别线索**

- 无脑损伤解释的意识状态改变
- 桡动脉脉搏微弱
- 桡动脉脉搏消失

**标准动作**

- 1. 完成失血性休克初筛并考虑立即启动休克复苏；优先级：immediate；条件：存在意识改变或桡动脉脉搏微弱或消失；时间要求：立即；说明：需排除脑损伤作为意识改变原因

**分支决策**

- 触发条件：意识改变无法用脑损伤解释和或桡动脉脉搏微弱或消失；下一步：按失血性休克处理并考虑立即复苏；依据：指南将其定义为现场休克识别标准；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 无

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Basic Management Plan for Tactical Field Care | 3.d
  - 原文：Perform initial assessment for hemorrhagic shock (altered mental status in the absence of brain injury and/or weak or absent radial pulse) and consider immediate initiation of shock resuscitation efforts.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：HEM 模块内保留休克初筛卡

**评测要点**

- 是否提到 altered mental status in the absence of brain injury
- 是否提到 weak or absent radial pulse
- 是否提到考虑立即启动休克复苏

---

## HEM-017 既往隔衣止血带的重新定位方法

**核心问题**

对既往隔衣止血带应如何重新定位

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：procedure
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护复评，撤运平台复评
- 适用对象：成人战伤伤员
- 前置条件：既往止血带放在制服外；需重新评估止血带是否仍需要
- 不覆盖范围：不覆盖止血带转换为敷料；不覆盖交界区止血带

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 1. 暴露伤口并判断止血带是否仍有必要；优先级：immediate；条件：复评既往隔衣止血带；时间要求：立即；说明：先看是否真的需要止血带
- 2. 若仍需要止血带，在出血点近端 2 至 3 英寸处直接对皮肤放置第二根止血带；优先级：immediate；条件：既往隔衣止血带仍需保留止血功能；时间要求：立即；说明：第二根是复位用止血带
- 3. 在确认新止血带有效后再松开第一根止血带；优先级：high；条件：第二根已到位；时间要求：尽快；说明：确保放松前已止血

**分支决策**

- 触发条件：复评后确认原止血带并不需要；下一步：移除止血带并记录移除时间；依据：指南要求无必要时移除并记录；分支类型：deescalation

**复评要点**

- 重新定位后出血是否停止
- 如非截肢，远端脉搏是否消失

**常见错误**

- 无

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Circulation | 6.a.2
  - 原文：If it is needed, reposition any limb tourniquet placed over the uniform by applying a second one directly to the skin 2-3 inches above the bleeding site, then loosening the first tourniquet.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：承接 Care Under Fire 阶段隔衣止血带的复位

**评测要点**

- 是否提到暴露伤口复评
- 是否提到对皮肤在出血点近端 2 至 3 英寸重新放置第二根
- 是否提到随后松开原止血带

---

## HEM-018 止血带复评时检查远端脉搏的意义

**核心问题**

止血带复评时为何要检查远端脉搏

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：reassessment
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护复评，撤运平台复评
- 适用对象：成人战伤伤员
- 前置条件：止血带已在位；伤肢不是创伤性截肢
- 不覆盖范围：不覆盖截肢断端特殊评估

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 无

**分支决策**

- 触发条件：远端脉搏仍存在或出血持续；下一步：进一步拧紧止血带或并列追加第二根止血带；依据：指南要求同时消除出血和远端脉搏；分支类型：escalation

**复评要点**

- 活动性出血是否消失
- 远端脉搏是否消失

**常见错误**

- 只看表面不出血而不摸远端脉搏
- 在非截肢伤肢遗漏远端脉搏检查

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Circulation | 6.a.2
  - 原文：If there is no traumatic amputation, a distal pulse should be checked. If bleeding persists or a distal pulse is still present, consider additional tightening of the tourniquet or the use of a second tourniquet side-by-side with the first to eliminate both bleeding and the distal pulse.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：止血带复评关键点

**评测要点**

- 是否提到非截肢伤肢要查远端脉搏
- 是否提到目标是同时消除出血和远端脉搏
- 是否提到脉搏仍在说明需加强止血带

---

## HEM-019 可考虑将止血带转换为止血敷料或压力包扎的条件

**核心问题**

满足哪些条件时可考虑止血带转换为止血敷料或压力包扎

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：advanced
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护复评，撤运平台持续照护
- 适用对象：成人战伤伤员
- 前置条件：止血带或交界区止血带已在位；考虑降级为局部敷料管理
- 不覆盖范围：不覆盖超过 6 小时止血带的特殊边界；不覆盖 2 小时原则细则

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 无

**分支决策**

- 触发条件：伤员不在休克、能严密监测伤口、止血带并非用于截肢肢体；下一步：尽快将止血带转换为止血敷料或压力包扎；依据：指南要求三项条件同时满足才可转换；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 仅满足一两项条件就贸然转换
- 对截肢肢体仍尝试常规止血带转换

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Circulation | 6.a.3
  - 原文：Limb tourniquets and junctional tourniquets should be converted to hemostatic or pressure dressings as soon as possible if three criteria are met: the casualty is not in shock; it is possible to monitor the wound closely for bleeding; and the tourniquet is not being used to control bleeding from an amputated extremity.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：止血带转换三条件卡

**评测要点**

- 是否完整列出三项条件
- 是否提到适用于肢体和交界区止血带
- 是否提到转换目标是止血敷料或压力包扎

---

## HEM-020 止血带转换的 2 小时原则

**核心问题**

止血带转换的 2 小时原则如何应用

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：advanced
- 适用阶段：Tactical Field Care，TACEVAC，Prolonged Care Reference
- 适用场景：战术野战救护持续照护，撤运平台，延长照护参考
- 适用对象：成人战伤伤员
- 前置条件：已满足转换的基本适应条件
- 不覆盖范围：不覆盖超过 6 小时后的实验室监测边界

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 无

**分支决策**

- 触发条件：在 2 小时内且其他方法可控制出血；下一步：尽力在 2 小时内完成止血带转换；依据：指南要求 every effort should be made to convert in less than 2 hours；分支类型：if_then
- 触发条件：TCCC ASM 或 CLS 人员已超过 2 小时且无 TCCC CMC、CPP 或其他高级医疗人员指示；下一步：维持止血带原位并持续监测直到到达更高级别救治；依据：超出 2 小时的转换需要更高医疗监督；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 无

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Circulation | 6.a.3 NOTE
  - 原文：Every effort should be made to convert tourniquets in less than 2 hours if bleeding can be controlled with other means. TCCC ASM/CLS trained personnel, should not attempt tourniquet conversion beyond 2 hours post-application unless directed by TCCC CMC/CPP personnel or other advanced medical personnel.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：止血带 2 小时转换原则

**评测要点**

- 是否提到应尽量在 2 小时内转换
- 是否提到前提是其他方法可控制出血
- 是否提到超过 2 小时时基层人员需高级医疗指示

---

## HEM-021 止血带已使用超过 6 小时时的处理边界

**核心问题**

止血带已使用超过 6 小时时的处理边界是什么

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：advanced
- 适用阶段：Tactical Field Care，TACEVAC，Prolonged Care Reference
- 适用场景：撤运平台，延长照护参考
- 适用对象：成人战伤伤员
- 前置条件：止血带已在位超过 6 小时
- 不覆盖范围：不覆盖院内 definitive management

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 无

**分支决策**

- 触发条件：止血带已超过 6 小时且现场缺乏严密监测与实验室能力；下一步：继续保持止血带在位并监测；依据：指南限定移除边界依赖 close monitoring and lab capability；分支类型：if_then

**复评要点**

- 无

**常见错误**

- 超过 6 小时后在缺乏监测条件下自行移除止血带

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Circulation | 6.a.3
  - 原文：Do not remove a tourniquet that has been in place more than 6 hours unless close monitoring and lab capability are available.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：止血带超过 6 小时的边界卡

**评测要点**

- 是否提到超过 6 小时
- 是否提到 close monitoring and lab capability
- 是否提到否则保持止血带原位

---

## HEM-022 止血带时间节点的记录要求

**核心问题**

止血带的放置时间、重置时间、转换时间、移除时间应如何记录

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：documentation
- 难度：basic
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台，伤员交接
- 适用对象：成人战伤伤员
- 前置条件：已应用止血带或完成止血带相关操作
- 不覆盖范围：不覆盖其他文书项目

**触发条件**

- 无

**识别线索**

- 无

**标准动作**

- 1. 暴露所有止血带并清晰标记止血带放置时间；优先级：high；条件：止血带在位；时间要求：尽快；说明：可用永久性记号笔
- 2. 在 TCCC Casualty Card 上记录放置时间、重新放置时间、转换时间和移除时间；优先级：high；条件：发生相应操作后；时间要求：及时；说明：同步记录在止血带和伤员卡上

**分支决策**

- 无

**复评要点**

- 无

**常见错误**

- 只在口头交接中说明时间而未书面记录
- 止血带被衣物遮挡导致时间不可见

**记录要求**

- 记录止血带放置时间
- 记录止血带重新放置时间
- 记录止血带转换时间
- 记录止血带移除时间

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Circulation | 6.a.4
  - 原文：Expose and clearly mark all tourniquets with the time of tourniquet application. Note tourniquets applied and time of application; time of reapplication; time of conversion; and time of removal on the TCCC Casualty Card.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：止血带文书卡

**评测要点**

- 是否提到暴露并清晰标记止血带
- 是否提到在 TCCC Casualty Card 记录四类时间
- 是否提到使用永久性记号笔

---

## HEM-023 疑似骨盆骨折时使用骨盆固定带的时机

**核心问题**

疑似骨盆骨折何时使用骨盆固定带

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：decision
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：存在严重钝性伤或爆炸伤机制
- 不覆盖范围：不覆盖骨盆固定带具体放置技术

**触发条件**

- 怀疑骨盆骨折

**识别线索**

- 严重钝性伤或爆炸伤
- 伴有骨盆骨折提示线索

**标准动作**

- 1. 对疑似骨盆骨折伤员应用骨盆固定带；优先级：high；条件：严重钝性伤或爆炸伤并伴提示线索；时间要求：尽快；说明：用于降低骨盆相关出血风险

**分支决策**

- 无

**复评要点**

- 无

**常见错误**

- 无

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Circulation | 6.a.1
  - 原文：A pelvic binder should be applied for cases of suspected pelvic fracture.

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：骨盆固定带时机卡

**评测要点**

- 是否提到 suspected pelvic fracture
- 是否提到严重钝性伤或爆炸伤背景
- 是否提到应使用骨盆固定带

---

## HEM-024 提示骨盆固定带适应证的高危线索

**核心问题**

提示骨盆固定带适应证的高危线索有哪些

**适用场景与适用对象**

- 主题模块：HEM / 大出血控制
- 任务类型：recognition
- 难度：intermediate
- 适用阶段：Tactical Field Care，TACEVAC
- 适用场景：战术野战救护，撤运平台
- 适用对象：成人战伤伤员
- 前置条件：存在严重钝性伤或爆炸伤机制
- 不覆盖范围：不覆盖骨盆固定带放置手法

**触发条件**

- 无

**识别线索**

- 骨盆痛
- 任何重大下肢截肢或近截肢
- 查体提示骨盆骨折
- 意识丧失
- 休克

**标准动作**

- 无

**分支决策**

- 无

**复评要点**

- 无

**常见错误**

- 无

**记录要求**

- 无

**来源依据**

- Tactical Combat Casualty Care (TCCC) Guidelines | 2026-05-01 | Circulation | 6.a.1
  - 原文：Severe blunt force or blast injury with one or more of the following indications: Pelvic pain; Any major lower limb amputation or near amputation; Physical exam findings suggestive of a pelvic fracture; Unconsciousness; Shock

**审校状态**

- 版本：1.0
- 证据级别：guideline
- 审核状态：draft
- 审核人：无
- 创建时间：2026-05-13
- 更新时间：2026-05-13
- 备注：骨盆固定带适应证线索卡

**评测要点**

- 是否提到严重钝性伤或爆炸伤机制
- 是否列出骨盆痛
- 是否列出重大下肢截肢或近截肢
- 是否列出查体提示骨盆骨折、意识丧失或休克

---

