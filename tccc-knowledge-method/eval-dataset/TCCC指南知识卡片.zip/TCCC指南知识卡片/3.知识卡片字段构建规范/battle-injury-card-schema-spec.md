# 战伤知识卡片字段规范

## 1. 文档目的

本规范用于定义战伤知识卡片的标准字段结构，确保卡片可以稳定支持以下用途：

1. 知识库检索。
2. RAG 召回与引用。
3. SFT 训练样本生成。
4. benchmark 评测集生成。
5. 专家审校与版本管理。

本规范与以下文档配套使用：

1. `.monkeycode/docs/battle-injury-card-splitting-spec.md`
2. `.monkeycode/docs/tccc-2026-knowledge-card-breakdown.md`

## 2. 设计原则

字段设计遵循以下原则：

1. 单卡片只表达一个最小可训练单元。
2. 同一字段只承载一种语义。
3. 结构化字段优先于长文本字段。
4. 同时兼容机器训练与专家阅读。
5. 支持版本追踪、来源追踪和审校追踪。

## 3. 卡片对象分层

一张完整卡片由 6 个字段层组成：

1. 标识层。
2. 分类层。
3. 任务语义层。
4. 医学内容层。
5. 训练与评测层。
6. 治理与版本层。

## 4. 字段总表

### 4.1 标识层字段

| 字段名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `card_id` | string | 是 | 卡片唯一编号 |
| `title` | string | 是 | 卡片标题，直接表达核心问题 |
| `version` | string | 是 | 卡片版本号，如 `1.0` |

### 4.2 分类层字段

| 字段名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `module` | string | 是 | 所属主题模块，如 `HEM` |
| `topic` | string | 是 | 所属主题名称，如 `大出血控制` |
| `task_type` | string | 是 | 卡片任务类型 |
| `training_use` | array[string] | 是 | 训练用途标签 |
| `difficulty` | string | 是 | 难度等级 |
| `applicable_phase` | array[string] | 是 | 适用阶段 |

### 4.3 任务语义层字段

| 字段名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `core_question` | string | 是 | 卡片回答的唯一核心问题 |
| `output_goal` | string | 是 | 本卡希望模型学会输出什么 |
| `applicable_scene` | array[string] | 是 | 适用场景 |
| `applicable_population` | array[string] | 是 | 适用对象 |
| `preconditions` | array[string] | 否 | 前置条件 |
| `exclusions` | array[string] | 是 | 不覆盖范围 |
| `related_cards` | array[string] | 否 | 关联卡片编号 |

### 4.4 医学内容层字段

| 字段名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `trigger_conditions` | array[string] | 否 | 触发条件 |
| `recognition_cues` | array[string] | 否 | 识别线索 |
| `key_actions` | array[object] | 否 | 关键处置动作 |
| `decision_points` | array[object] | 否 | 决策分支 |
| `reassessment_points` | array[string] | 否 | 复评要点 |
| `endpoints` | array[string] | 否 | 成功终点或目标终点 |
| `common_errors` | array[string] | 否 | 常见错误 |
| `contraindications_or_cautions` | array[string] | 否 | 禁忌与注意事项 |
| `documentation_requirements` | array[string] | 否 | 需要记录的信息 |

### 4.5 训练与评测层字段

| 字段名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `qa_seed_questions` | array[string] | 否 | 可直接生成训练问答的种子问题 |
| `case_seed_prompts` | array[string] | 否 | 可直接生成病例题的种子提示 |
| `evaluation_points` | array[string] | 是 | 自动或专家评测的关键点 |
| `structured_output_hint` | object | 否 | 下游任务的推荐结构化输出提示 |

### 4.6 治理与版本层字段

| 字段名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `source_refs` | array[object] | 是 | 来源文献引用 |
| `evidence_level` | string | 是 | 证据级别 |
| `review_status` | string | 是 | 审核状态 |
| `reviewers` | array[string] | 否 | 审核人 |
| `created_at` | string | 是 | 创建日期 |
| `updated_at` | string | 是 | 更新日期 |
| `notes` | string | 否 | 编辑备注 |

## 5. 必填字段最小集合

为了保证卡片可落库、可训练、可评测，每张卡片至少应包含以下字段：

1. `card_id`
2. `title`
3. `version`
4. `module`
5. `topic`
6. `task_type`
7. `training_use`
8. `difficulty`
9. `applicable_phase`
10. `core_question`
11. `output_goal`
12. `applicable_scene`
13. `applicable_population`
14. `exclusions`
15. `evaluation_points`
16. `source_refs`
17. `evidence_level`
18. `review_status`
19. `created_at`
20. `updated_at`

## 6. 枚举值规范

### 6.1 `task_type`

限定值：

1. `recognition`
2. `procedure`
3. `decision`
4. `triage`
5. `reassessment`
6. `error_prevention`
7. `documentation`
8. `communication`

### 6.2 `training_use`

可多选，限定值：

1. `fact_qa`
2. `case_qa`
3. `structured_decision`
4. `ranking`
5. `error_correction`
6. `retrieval`
7. `judge_eval`

### 6.3 `difficulty`

限定值：

1. `basic`
2. `intermediate`
3. `advanced`

### 6.4 `applicable_phase`

可多选，限定值：

1. `care_under_threat`
2. `tactical_field_care`
3. `tacevac`
4. `prolonged_care_reference`

### 6.5 `evidence_level`

限定值：

1. `guideline`
2. `consensus`
3. `expert_summary`
4. `case_derived`

### 6.6 `review_status`

限定值：

1. `draft`
2. `internally_checked`
3. `expert_reviewed`
4. `approved`
5. `deprecated`

## 7. 复杂字段结构

### 7.1 `key_actions`

用于表达标准动作序列。建议结构如下：

```json
{
  "step": 1,
  "action": "直接对皮肤在出血点近端 2-3 英寸处放置止血带",
  "priority": "immediate",
  "condition": "存在可用止血带控制的致命性四肢外出血",
  "time_target": "尽快",
  "notes": "若首根无效，准备并列追加第二根"
}
```

字段说明：

1. `step`: 整数，表示步骤顺序。
2. `action`: 字符串，表示动作内容。
3. `priority`: 字符串，建议值为 `immediate`、`high`、`routine`。
4. `condition`: 字符串，可为空，表示该动作适用条件。
5. `time_target`: 字符串，可为空，表示时间要求。
6. `notes`: 字符串，可为空，表示补充说明。

### 7.2 `decision_points`

用于表达分支判断。建议结构如下：

```json
{
  "condition": "首根止血带后仍持续出血或远端脉搏持续存在",
  "next_action": "在首根止血带旁并列放置第二根止血带",
  "rationale": "需要同时消除活动性出血和远端脉搏",
  "branch_type": "if_then"
}
```

字段说明：

1. `condition`: 分支触发条件。
2. `next_action`: 下一步动作。
3. `rationale`: 分支依据。
4. `branch_type`: 建议值为 `if_then`、`if_else`、`escalation`、`deescalation`。

### 7.3 `source_refs`

用于记录来源依据。建议结构如下：

```json
{
  "source_id": "TCCC-2026",
  "title": "Tactical Combat Casualty Care (TCCC) Guidelines",
  "version": "2026-05-01",
  "section": "Massive Hemorrhage",
  "locator": "Tactical Field Care 3.a-3.d",
  "quote": "If bleeding is not controlled with the first tourniquet, apply a second tourniquet side-by-side with the first."
}
```

### 7.4 `structured_output_hint`

用于约束下游模型输出格式。建议结构如下：

```json
{
  "recommended_fields": [
    "injury_assessment",
    "priority",
    "immediate_actions",
    "reassessment",
    "rationale"
  ],
  "output_format": "json"
}
```

## 8. 字段填写规则

### 8.1 标题规则

`title` 应满足以下要求：

1. 直接对应一个核心问题。
2. 不使用宽泛标题。
3. 优先使用“X 识别”“X 初始处置”“X 升级处置”“X 复评”“X 记录与交接”这类格式。

### 8.2 核心问题规则

`core_question` 应满足以下要求：

1. 一张卡片只有一个核心问题。
2. 句式尽量标准化。
3. 问题表述应支持直接生成问答样本。

推荐句式：

1. 什么情况提示 X。
2. 发现 X 后第一步做什么。
3. X 处理失败后下一步是什么。
4. X 处置后需要复评什么。
5. X 的记录要求是什么。

### 8.3 适用边界规则

`applicable_scene`、`applicable_population`、`preconditions`、`exclusions` 必须共同定义卡片边界。

示例：

1. `applicable_scene`: `战场现场`, `Tactical Field Care`
2. `applicable_population`: `成人战伤伤员`
3. `preconditions`: `已确认存在致命性四肢外出血`
4. `exclusions`: `不覆盖止血带转换`, `不覆盖后送阶段持续监测`

### 8.4 医学内容规则

1. `recognition_cues` 只写识别证据点。
2. `key_actions` 只写可执行动作。
3. `decision_points` 只写条件分支。
4. `reassessment_points` 只写复查项目。
5. `common_errors` 优先记录高频、可纠正、会影响结果的错误。

### 8.5 评测点规则

`evaluation_points` 是评分依据，建议写成可判分条目：

1. 是否提到立即对皮肤放置止血带。
2. 是否提到出血未止时并列追加第二根止血带。
3. 是否提到检查远端脉搏。

## 9. 机器格式推荐

推荐统一采用 `JSON` 作为主存储格式，`Markdown` 作为专家审校展示格式。

建议目录组织如下：

```text
cards/
  HEM/
    HEM-001.json
    HEM-002.json
  AIR/
    AIR-001.json
reviews/
  HEM/
    HEM-001.md
```

## 10. 标准 JSON 示例

以下示例以 `HEM-005` 为例：

```json
{
  "card_id": "HEM-005",
  "title": "首根止血带后仍出血时的升级处置",
  "version": "1.0",
  "module": "HEM",
  "topic": "大出血控制",
  "task_type": "decision",
  "training_use": ["fact_qa", "case_qa", "structured_decision", "retrieval"],
  "difficulty": "basic",
  "applicable_phase": ["tactical_field_care", "tacevac"],
  "core_question": "首根止血带后仍持续出血时下一步是什么",
  "output_goal": "让模型输出止血失败后的标准升级处置",
  "applicable_scene": ["战场现场", "战术野战救护"],
  "applicable_population": ["成人战伤伤员"],
  "preconditions": ["已完成首根止血带放置", "四肢出血可用止血带控制"],
  "exclusions": ["不覆盖止血带转换", "不覆盖后送交接"],
  "related_cards": ["HEM-004", "HEM-018", "HEM-022"],
  "trigger_conditions": ["首根止血带后仍有活动性出血", "远端脉搏仍存在"],
  "recognition_cues": ["敷料持续浸透", "出血未停止", "远端脉搏未消失"],
  "key_actions": [
    {
      "step": 1,
      "action": "在首根止血带旁并列追加第二根止血带",
      "priority": "immediate",
      "condition": "首根止血带后仍未止血",
      "time_target": "立即",
      "notes": "目标是同时终止出血并消除远端脉搏"
    }
  ],
  "decision_points": [
    {
      "condition": "首根止血带后仍持续出血或远端脉搏持续存在",
      "next_action": "追加第二根止血带并列放置",
      "rationale": "单根压力不足以完全阻断出血和远端血流",
      "branch_type": "escalation"
    }
  ],
  "reassessment_points": ["活动性出血是否停止", "远端脉搏是否消失"],
  "endpoints": ["活动性出血停止", "远端脉搏消失"],
  "common_errors": ["只继续拧紧首根止血带而未及时追加第二根", "止血后未检查远端脉搏"],
  "contraindications_or_cautions": ["追加后仍需持续复评"],
  "documentation_requirements": ["记录追加止血带时间", "记录止血效果"],
  "qa_seed_questions": [
    "首根止血带无效时标准升级处置是什么",
    "为什么首根止血带后还要检查远端脉搏"
  ],
  "case_seed_prompts": [
    "伤员右下肢喷射样出血，首根止血带后仍渗血且足背动脉可触及，请给出处置"
  ],
  "evaluation_points": [
    "是否提到并列追加第二根止血带",
    "是否提到继续评估出血是否停止",
    "是否提到远端脉搏应消失"
  ],
  "structured_output_hint": {
    "recommended_fields": ["problem", "next_action", "reassessment", "rationale"],
    "output_format": "json"
  },
  "source_refs": [
    {
      "source_id": "TCCC-2026",
      "title": "Tactical Combat Casualty Care (TCCC) Guidelines",
      "version": "2026-05-01",
      "section": "Massive Hemorrhage",
      "locator": "Tactical Field Care 3.a",
      "quote": "If bleeding is not controlled with the first tourniquet, apply a second tourniquet side-by-side with the first."
    }
  ],
  "evidence_level": "guideline",
  "review_status": "draft",
  "reviewers": [],
  "created_at": "2026-05-12",
  "updated_at": "2026-05-12",
  "notes": "首版字段规范示例卡"
}
```

## 11. 专家阅读格式映射建议

为了方便专家审校，建议把 JSON 卡片映射成如下 Markdown 结构：

1. 卡片编号与标题
2. 核心问题
3. 适用场景与适用对象
4. 触发条件
5. 识别线索
6. 标准动作
7. 分支决策
8. 复评要点
9. 常见错误
10. 记录要求
11. 来源依据
12. 审校状态

## 12. 质控要求

字段层面的质控检查包括：

1. `card_id` 是否唯一。
2. `title` 与 `core_question` 是否一一对应。
3. `task_type` 是否与内容一致。
4. `exclusions` 是否明确。
5. `evaluation_points` 是否能直接用于评分。
6. `source_refs` 是否能追溯到原始文献章节。
7. `review_status` 是否与审校流程一致。

## 13. 实施建议

建议按以下顺序落地：

1. 先固定本字段规范为 `v1.0`。
2. 优先为 `HEM`、`AIR`、`RESP`、`CIRC`、`TBI` 模块建卡。
3. 每做完一个模块，先做字段一致性检查，再进入专家审校。
4. 经专家审校后的卡片再生成训练样本与评测样本。
